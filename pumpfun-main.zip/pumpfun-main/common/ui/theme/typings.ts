declare module '@mui/material/styles' {
  interface Palette {
    color?: {
      cardBg: string
    };
  }

  interface PaletteOptions {
    color?: {
      cardBg: string
    }
  }
}


export {}
